fluidPage(
  textOutput("currentTime")
)
